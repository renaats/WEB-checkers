var gameStatus = {
    since: Date.now(),
    gamesPlayed: 0,
    movesMade: 0,
    playersIngame: 0,
    ongoingGames: 0
  };

  module.exports = gameStatus;